---
name: archive-examples
description: 压缩包中的教学方法
---
用反例帮助理解边界。
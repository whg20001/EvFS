---
name: root-method
description: 多 Skill 包中的教学方法
---
分别核对边界和反例。